import kivy
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager
from DatosCompartidos import DatosCompartidos
from MenuPrincipal import menuPrincipal
from PantallaJuego import pantallaJuego
from GameOver import gameOver
from Victoria import victoria
from Score import score

class Principal(App):
    def build(self):
        mPantalla=ScreenManager()
        DcCompa=DatosCompartidos()
        p1=menuPrincipal(name="Menu Principal").build(SM=mPantalla, DC=DcCompa)
        p2 = pantallaJuego(name="Pantalla Juego").build(SM=mPantalla, DC=DcCompa)
        p3 = gameOver(name="Game Over").build(SM=mPantalla, DC=DcCompa)
        p4 = victoria(name="Victoria").build(SM=mPantalla, DC=DcCompa)
        p5 = score(name="Score").build(SM=mPantalla, DC=DcCompa)
        mPantalla.add_widget(p1)
        mPantalla.add_widget(p2)
        mPantalla.add_widget(p3)
        mPantalla.add_widget(p4)
        mPantalla.add_widget(p5)
        mPantalla.current="Menu Principal"
        return mPantalla

if __name__=='__main__':
    miapp=Principal()
    miapp.run()