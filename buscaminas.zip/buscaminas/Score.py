import json

import kivy
import pymysql
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

from ColorLabel import ColorLabel
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
kivy.require("1.9.1")
from kivy.uix.screenmanager import Screen


class score(Screen):
    lista=[]
    def volver(self, obj):
        self.SM.current = "Menu Principal"

    def iniciarBD(self):
        print("iniciando base de datos score")  ##iciar y crear tablas
        Conf = None
        with open("accesoJson.json") as jsonfile:
            Conf = json.load(jsonfile)
        self.connection = pymysql.connect(
            host=Conf['HOST'], user=Conf['DBUSER'],
            password=Conf['DBPASS'], database=Conf['DBNAME'],
            charset='utf8mb4', port=Conf['PORT'])
        if self.connection:
            print("conexion realizada")

    def extraerRecords(self):
        self.MiCursor = self.connection.cursor()
        self.MiCursor.execute("Select * from puntaje")
        Tupla=self.MiCursor.fetchall()
        for i in range(0,10,1):
            if Tupla[i][1]==None:
                b="None"
            else:
                b=Tupla[i][1]
            self.lista.append([Tupla[i][0],b,Tupla[i][2]])
        print(type(self.lista))

    def crearPDF(self, obj):
        c = canvas.Canvas("SCORE.pdf", pagesize=letter)
        c.line(40, 720, 572, 720)
        a = 720
        for i in range(-1, 10, 1):
            if i==-1:
                b = a
                a = a - 20
                c.line(40, a, 572, a)  # linea inferior
                c.line(40, b, 40, a)  # primer linea vertical
                c.drawCentredString(93, a + 5, "Lugar")
                c.line(146, b, 146, a)  #Primer campo
                c.drawCentredString(292.25, a + 5, "nombre")
                c.line(438.5, b, 438.5, a) ##segndo campo
                c.drawCentredString(505.25, a + 5, "Puntaje")
                c.line(572, b, 572, a)
            else:
                b = a
                a = a - 20
                c.line(40, a, 572, a)  # linea inferior
                c.line(40, b, 40, a)  # primer linea vertical
                c.drawCentredString(93, a + 5, str(self.lista[i][0]))
                c.line(146, b, 146, a)  # Primer campo
                c.drawCentredString(292.25, a + 5, str(self.lista[i][1]))
                c.line(438.5, b, 438.5, a)  ##segndo campo
                c.drawCentredString(505.25, a + 5, str(self.lista[i][2]))
                c.line(572, b, 572, a)
        c.save()


    def build(self, SM=None, DC=None):
        self.SM = SM
        self.DC = DC
        self.iniciarBD()
        self.extraerRecords()
        principal=GridLayout(rows=2)
        record=GridLayout(rows=11, cols=3)
        lbl1=ColorLabel(text="Lugar")
        lbl2=ColorLabel(text="Nombre")
        lbl3=ColorLabel(text="puntaje")
        record.add_widget(lbl1)
        record.add_widget(lbl2)
        record.add_widget(lbl3)
        lista=[]
        for i in range(0,10,1):
            lista.append([None, None, None])
        print(lista)
        for i in range(0,10,1):
            lista[i][0]=ColorLabel(text=str(self.lista[i][0]))
            lista[i][1]=ColorLabel(text=self.lista[i][1])
            lista[i][2]=ColorLabel(text=str(self.lista[i][2]))
            record.add_widget(lista[i][0])
            record.add_widget(lista[i][1])
            record.add_widget(lista[i][2])
        principal.add_widget(record)
        botones=BoxLayout(orientation="vertical",size_hint_y=None, height=200)
        btnPDF=Button(text="Crear Doc PDF")
        btnMP=Button(text="Volver a Menú Principal")
        botones.add_widget(btnPDF)
        botones.add_widget(btnMP)
        btnMP.bind(on_press=self.volver)
        btnPDF.bind(on_press=self.crearPDF)
        principal.add_widget(botones)
        self.add_widget(principal)
        return self

if __name__ == '__main__':
    pass