import json

import kivy
import pymysql
from kivy.app import App
from kivy.core.window import Window
from kivy.uix.textinput import TextInput
from ColorLabel import ColorLabel
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
kivy.require("1.9.1")
from kivy.uix.screenmanager import Screen
from kivy.clock import Clock

class victoria(Screen):
    lista=[]
    banderaDC=0
    puntaje=0

    def Callback_Clock(self, dt):
            self.banderaDC=1
            self.puntaje=self.DC.segundos
            self.lblpuntaje.text="tu puntaje es: "+str(self.DC.segundos)
            print("DC.segundos", self.DC.segundos)

    def iniciarBD(self):
        print("iniciando base de datos victoria")  ##iciar y crear tablas
        Conf = None
        with open("accesoJson.json") as jsonfile:
            Conf = json.load(jsonfile)
        self.connection = pymysql.connect(
            host=Conf['HOST'], user=Conf['DBUSER'],
            password=Conf['DBPASS'], database=Conf['DBNAME'],
            charset='utf8mb4', port=Conf['PORT'])
        if self.connection:
            print("conexion realizada")

    def extraerRecords(self):
        self.MiCursor = self.connection.cursor()
        self.MiCursor.execute("Select * from puntaje")
        Tupla=self.MiCursor.fetchall()
        for i in range(0,10,1):
            self.lista.append([Tupla[i][0],Tupla[i][1],Tupla[i][2]])
        print(type(self.lista))



    def continuar(self):
        puntero=-1
        inicioCeros = -1
        finCeros = 9
        for i in range(0, 10, 1):
            if self.lista[i][2] == 0:
                inicioCeros = i
                break
        if self.DC.segundos > self.lista[inicioCeros - 1][2]:
            self.lista[inicioCeros][1] = self.a
            self.lista[inicioCeros][2] = self.DC.segundos
        else:
            for i in range(0, inicioCeros, 1):
                if self.DC.segundos< self.lista[i][2]:
                    puntero = i
                    break
            for i in range(9, puntero, -1):
                self.lista[i][1] = self.lista[i - 1][1]
                self.lista[i][2] = self.lista[i - 1][2]
            self.lista[puntero][1] = self.a
            self.lista[puntero][2] = self.DC.segundos
        instrucciones=[]
        for i in range(0,10,1):
            sql="UPDATE puntaje SET nombre=%s,puntaje=%s WHERE Lugar=%s;"
            self.MiCursor.execute(sql, [self.lista[i][1],self.lista[i][2], self.lista[i][0]])
        self.connection.commit()
        App.get_running_app().stop()
        # removing window
        Window.close()



    def acortarTexto(self, obj):
        self.a = None
        self.a = self.cajaNombre.text
        print(self.a)
        if 0 < len(self.a) <= 20:
                self.DC.nombre=self.a
                self.cajaNombre.text = ""
                self.continuar()
                ##################33aqui pasara a la 3 pantallas
        else:
            self.cajaNombre.text = ""
            self.lblverificar.text = 'ingresa una cadena de 20 caracteres o menos (no se aceptan cadenas vacias)'

    def build(self, SM=None, DC=None):
        Clock.schedule_interval(self.Callback_Clock, 1)
        self.iniciarBD()
        self.extraerRecords()
        self.SM = SM
        self.DC = DC
        box=BoxLayout(orientation="vertical")
        lblFelicidades=ColorLabel(text="FELICIDADES")
        lblFelicidades.background_color=[1,0.85,0,1]
        lblFelicidades.font_size=20
        self.cajaNombre=TextInput(text="")
        self.lblverificar=ColorLabel(text="Ingresa tu nombre (maximo 20 letras)")
        self.lblpuntaje = ColorLabel(text="tu puntaje es: "+str(self.puntaje))
        btnGuardar=Button(text="Guardar")
        box.add_widget(lblFelicidades)
        box.add_widget(self.cajaNombre)
        box.add_widget(self.lblverificar)
        box.add_widget(self.lblpuntaje)
        box.add_widget(btnGuardar)
        btnGuardar.bind(on_press=self.acortarTexto)
        self.add_widget(box)
        return self

if __name__ == '__main__':
    pass