import kivy
from kivy.uix.screenmanager import Screen
from ColorLabel import ColorLabel
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
kivy.require("1.9.1")
import random
from kivy.clock import Clock
#from DatosCompartidos import DatosCompartidos

class pantallaJuego(Screen):
    segundos=0
    jugando = True
    contador=0
    ganador=False
    inicio=0

    def verPos(self, obj):
        self.inicio=1
        if self.jugando==True:
            if self.oculto[obj.casilla[0]][obj.casilla[1]]==9:
                obj.text="*"
                obj.background_color=[1,0,0,1]
                self.jugando = False
                self.perder()
            elif self.oculto[obj.casilla[0]][obj.casilla[1]]!=0:
                obj.text=str(self.oculto[obj.casilla[0]][obj.casilla[1]])
                obj.disabled=True
                self.contador=self.contador+1

            elif self.oculto[obj.casilla[0]][obj.casilla[1]]==0:
                obj.disabled=True
                self.contador = self.contador + 1


    def perder(self):
        self.SM.current = "Game Over"
        self.ganador = False
        self.inicio = 0
        self.jugando=True
        self.DC.segundos=0
        self.contador=0

    def minasRandom(self):
        self.posicionMinas = []  ###############posicionMinas = minas_ocultas
        numero = 0
        while numero < 2:
            x = random.randint(0, 8 - 1)  ###########filas
            y = random.randint(0, 8 - 1)  ############ columnas
            if self.oculto[x][y] != 9:
                self.oculto[x][y] = 9
                numero += 1
                self.posicionMinas.append((x, y))
        # print(posicionMinas)

    def coloca_pista(self):
        for x in range(8):
            for y in range(8):
                if self.oculto[x][y] == 9:
                    for i in [-1, 0, 1]:
                        for j in [-1, 0, 1]:
                            if (0 <= x + i <= 8 - 1) and (0 <= y + j <= 8 - 1):
                                if self.oculto[x + i][y + j] != 9:
                                    self.oculto[x + i][y + j] += 1

    def Callback_Clock(self, dt):
        self.winCond()
        if self.jugando==True and self.ganador==False and self.SM.current=="Pantalla Juego" and self.inicio==1:
            self.segundos = self.segundos + 1
            self.lblCrono.text = "tiempo: % d..." % self.segundos
        if self.ganador==True:
            self.ganar()
            self.DC.segundos=self.segundos
            self.ganador=False
            self.inicio=0
            print(self.DC.segundos)

    def winCond(self):
        if self.contador==62 and self.jugando==True:
            self.ganador=True

    def ganar(self):
        self.SM.current = "Victoria"

    #DCobj=DatosCompartidos()

    def build(self, SM=None, DC=None):
        self.SM = SM
        self.DC = DC
       # self.DCobj.segundos=0
        principal=GridLayout(rows=2)
        lineaSuperior=BoxLayout(orientation="horizontal",size_hint_y=None, height=100)
        self.lbl1=ColorLabel(text="")
        self.lbl1.background_color=[0,0,0,1]
        self.lblCrono=ColorLabel(text=str(self.segundos))
        self.lblCrono.background_color=[0.4,0.4,0.4,1]
        lbl3=ColorLabel(text="")
        lbl3.background_color=[0,0,0,1]
        lineaSuperior.add_widget(self.lbl1)
        lineaSuperior.add_widget(self.lblCrono)
        lineaSuperior.add_widget(lbl3)
        principal.add_widget(lineaSuperior)
        a = []
        self.oculto = []
        self.visible = []
        # b.key=0
        for i in range(0, 8, 1):
            a.append(None)

        for i in range(0, 8, 1):
            # print(i)
            self.visible.append(a)
            self.oculto.append([0,0,0,0,0,0,0,0])
        self.minasRandom()
        self.coloca_pista()
        cuadricula=GridLayout(rows=8, cols=8)
        for i in range(0, 8, 1):
            for j in range(0, 8, 1):
                self.visible[i][j] = Button(text="")
                self.visible[i][j].background_color = [0.6,0.6,0.6,1]
                self.visible[i][j].casilla=[i,j]
                self.visible[i][j].bind(on_press=self.verPos)
                cuadricula.add_widget(self.visible[i][j])

            print(self.oculto[i])
        principal.add_widget(cuadricula)
        Clock.schedule_interval(self.Callback_Clock, 1)
        self.add_widget(principal)
        return self

if __name__ == '__main__':
    pass