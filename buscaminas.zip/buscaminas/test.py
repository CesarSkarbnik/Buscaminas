import json
import pymysql



def iniciarBD():
    print("iniciando base de datos victoria")  ##iciar y crear tablas
    Conf = None
    with open("accesoJson.json") as jsonfile:
        Conf = json.load(jsonfile)
    connection = pymysql.connect(
        host=Conf['HOST'], user=Conf['DBUSER'],
        password=Conf['DBPASS'], database=Conf['DBNAME'],
        charset='utf8mb4', port=Conf['PORT'])
    if connection:
        print("conexion realizada")
    return connection

def extraerRecords():
        connection=iniciarBD()
        MiCursor = connection.cursor()
        MiCursor.execute("Select * from puntaje;")
        resultado=MiCursor.fetchall()
        if resultado:
            print("verdadero")
        else:
            print("falso")

extraerRecords()