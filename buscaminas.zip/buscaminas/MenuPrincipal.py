import json

import kivy
import pymysql
from kivy.uix.screenmanager import Screen
from ColorLabel import ColorLabel
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
kivy.require("1.9.1")

class menuPrincipal(Screen):
    ban=False
    def iniciarBD(self):
        print("iniciando base de datos")  ##iciar y crear tablas
        Conf = None
        with open("accesoJson.json") as jsonfile:
            Conf = json.load(jsonfile)
        self.connection = pymysql.connect(
            host=Conf['HOST'], user=Conf['DBUSER'],
            password=Conf['DBPASS'], database=Conf['DBNAME'],
            charset='utf8mb4', port=Conf['PORT'])
        if self.connection:
            print("conexion realizada")
            self.decidir()


    def decidir(self):
        print("entrando a decidir")
        instrucciones = []
        self.MiCursor = self.connection.cursor()
        self.MiCursor.execute("show tables")
        print("se ejecuto show tables")
        resultado = self.MiCursor.fetchall()
        print(resultado)
        print(len(resultado))
        for i in range(0, len(resultado), 1):
            print(resultado[i][0])
            if resultado[i][0] == "Puntaje" or resultado[i][0]=="puntaje":
                print(resultado[i][0]+"= puntaje")
                self.ban = True
                break
        print(self.ban)
        if self.ban==False:
            abc = """create table if not exists Puntaje(Lugar smallint(2)  unsigned primary KEY auto_increment,
                                                Nombre varchar(20) null,
                                                puntaje SMALLINT(3) unsigned not null)engine=InnoDB;"""
            instrucciones.append(abc)
            for i in range(0, 10, 1):
                abc = "INSERT INTO Puntaje VALUES(NULL,NULL,0)"
                instrucciones.append(abc)
            for i in range(0, len(instrucciones), 1):
                print(instrucciones[i])
                self.MiCursor.execute(instrucciones[i])
        self.connection.commit()


    def nuevoJuego(self, obj): ####metodo boton nuevo juego
        self.SM.current = "Pantalla Juego"

    def verRecords(self, obj): ####metodo boton records
        self.SM.current = "Score"


    def build(self, SM=None, DC=None):
        self.SM = SM
        self.DC = DC
        self.iniciarBD()
        box=BoxLayout(orientation="vertical")
        lbl=ColorLabel(text="juego de buscaminas")
        lbl.background_color=[0.7,0.7,0.7,1]
        lbl.font_size=25
        box.add_widget(lbl)
        btn1=Button(text="Nuevo Juego")
        box.add_widget(btn1)
        btn1.bind(on_press=self.nuevoJuego)
        btn2=Button(text="VER RECORDS")
        box.add_widget(btn2)
        btn2.bind(on_press=self.verRecords)
        self.add_widget(box)
        return self

if __name__ == '__main__':
    pass