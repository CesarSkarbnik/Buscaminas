#####pantalla de juego
import os
import random

#####################crear tablero
def crearTablero(fil,col,val):
    tablero=[]
    for i in range(fil):
        tablero.append([])
        for j in range(col):
            tablero[i].append(val)
    return tablero

#########################Mostrar en pantalla el tablero
def muestraTablero(tablero):
    for fila in tablero:
        for elem in fila:
            print(elem, end="")
        print()

def minasRandom(tablero, minas, fil, col):
    posicionMinas=[] ###############posicionMinas = minas_ocultas
    numero= 0
    while numero<minas:
        x=random.randint(0, fil-1) ###########filas
        y=random.randint(0, fil-1)############ columnas
        if tablero[x][y]!=9:
            tablero[x][y]=9
            numero+=1
            posicionMinas.append((x,y))
    #print(posicionMinas)
    return tablero, posicionMinas

def coloca_pista(tablero, fil, col):
    for x in range(fil):
        for y in range(col):
            if tablero[x][y]==9:
                for i in [-1,0,1]:
                    for j in [-1,0,1]:
                        if (0 <= x+i <= fil-1) and (0 <= y+j <= col-1):
                            if tablero[x+i][y+j]!=9:
                                tablero[x+i][y+j]+=1
    return tablero

def presentacion():
    os.system("cls")
    input("Juego de buscaminas \n"
        +"presiona enter para empezar")

def menu():
    print()
    opcion=input("presiona w/a/s/d")
    return opcion

def rellenado(oculto, visible, x, y, fil, col, val):
    ceros=[(x,y)]
    while len(ceros)>0:
        x,y=ceros.pop()
        for i in [-1,0,1]:
            for j in [-1,0,1]:
                if 0<=x+i<=fil-1 and 0<=y+j<=col-1:
                    if visible[x+i][y+j]==val and oculto[x+i][y+j]==0:
                        visible[x+i][y+j]=0
                        if (x+i, y+j) not in ceros:
                            ceros.append((x+i, y+j))
                    else:
                        visible[x+i][y+j]=oculto[x+i][y+j]
    return visible

def tableroCompleto(tablero, fil, col, val):
    for x in range(fil):
        for y in range(col):
            if tablero[x][y]==val:
                return False
    return True

def tableroCompleto2(tablero, fil, col, val, mines):
    contador=0
    a=len(mines)
    for x in range(fil):
        for y in range(col):
            if tablero[x][y]==val:
                contador+=1
            if tablero[x][y]=="#":
                a-=1
    if contador==a:
        return True
    else:
        return False

def reemplazaCeros(tablero):
    for i in range(8):
        for j in range(8):
            if tablero[i][j]==0:
                tablero[i][j] = 0
    return tablero

columnas = filas = 8
tableroVisible = crearTablero(filas, columnas, "-")
tableroOculto= crearTablero(filas, columnas, 0)
tableroOculto, posicionMinas = minasRandom(tableroOculto, 2, filas, columnas)
tableroOculto=coloca_pista(tableroOculto, filas, columnas)
presentacion()
x=random.randint(2, filas-3) ###########filas
y=random.randint(2, columnas-3)
real = tableroVisible[x][y]
tableroVisible[x][y]="x"
os.system("cls")
muestraTablero(tableroVisible)
minasMarcadas=[]
jugando=True
while jugando:
    mov=menu()
    if mov=="w":
        if x==0:
            x=0
        else:
            tableroVisible[x][y]=real
            x-=1
            real=tableroVisible[x][y]
            tableroVisible[x][y]="x"
    elif mov=="s":
        if x == filas-1:
            x=filas-1
        else:
            tableroVisible[x][y]=real
            x+=1
            real=tableroVisible[x][y]
            tableroVisible[x][y]="x"
    elif mov=="a":
        if y == 0:
            y=0
        else:
            tableroVisible[x][y]=real
            y-=1
            real=tableroVisible[x][y]
            tableroVisible[x][y]="x"
    elif mov == "d":
        if y == columnas-1:
            y = columnas-1
        else:
            tableroVisible[x][y] = real
            y += 1
            real = tableroVisible[x][y]
            tableroVisible[x][y] = "x"
    elif mov=="b":
        if real=="-":
            tableroVisible[x][y]="#"
            real=tableroVisible[x][y]
            if (x,y) not in minasMarcadas:
                minasMarcadas.append((x,y))
    elif mov=="v":
        if real=="#":
            tableroVisible[x][y]="-"
            real=tableroVisible[x][y]
            if (x,y) in minasMarcadas:
                minasMarcadas.remove((x,y))
    elif mov == "m":
        if tableroOculto[x][y]==9:
            tableroVisible[x][y]="@"
            jugando = False
        elif tableroOculto[x][y]!=0:
            tableroVisible[x][y]=tableroOculto[x][y]
            real=tableroVisible[x][y]
        elif tableroOculto[x][y]==0:
            tableroVisible[x][y]=0
            tableroVisible=rellenado(tableroOculto, tableroVisible, x, y, filas, columnas, "-")
            tableroVisible=reemplazaCeros(tableroVisible)
            real=tableroVisible[x][y]
    os.system("cls")
    muestraTablero(tableroVisible)
    ganas=False
    if (tableroCompleto(tableroVisible, filas, columnas, "-") and \
        sorted(posicionMinas) == sorted(minasMarcadas) and \
        real !="-") or (tableroCompleto2(tableroVisible, filas, columnas, "-", posicionMinas) and tableroVisible[x][y]!="x"):
            ganas=True
            jugando=False
if not ganas:
    print("------------------------------------\n"+
          "------------HAS PERDIDO-------------\n"+
          "------------------------------------")
else:
    print("------------------------------------\n" +
          "-------------HAS GANADO-------------\n" +
          "------------------------------------")
