class DatosCompartidos:

    def __init__(self):
        print("entrando a DAtos compartidos")
        self.segundos=0
        self.nombre=""